import java.util.LinkedList;

public class Contenedor<T extends Volumen> implements Generico, Volumen{

	private double volumen;
	private LinkedList<T> productos;
	private double almacenado;
	
	public Contenedor(double volumen){
		productos = new LinkedList<T>();
		this.volumen=volumen;
		almacenado=0.0;
	}

	public boolean guardar(T elemento){
		if(elemento.volumen() <= (volumen-almacenado)){
			productos.addLast(elemento);
			almacenado+=elemento.volumen();
			return true;		
		}
		return false;
	}

	public double volumen(){
		return volumen;
	}
}
