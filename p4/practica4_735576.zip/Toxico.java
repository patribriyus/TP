public class Toxico extends General{
	public Toxico(double volumen, String info){
		super(volumen, info);
	}
}
