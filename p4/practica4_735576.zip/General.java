public class General implements Volumen{
	
	private double volumen;
	private String info;
	
	public General(double volumen, String info){
		this.volumen=volumen;
		this.info=info;
	}

	public double volumen(){
		return volumen;
	}

}
