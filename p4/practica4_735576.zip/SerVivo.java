public class SerVivo extends General{
	public SerVivo(double volumen, String info){
		super(volumen, info);
	}
}
