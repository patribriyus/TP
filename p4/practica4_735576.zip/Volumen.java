public interface Volumen{
	
	public double volumen();
}
