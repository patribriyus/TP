import java.util.LinkedList;

public class Camion{

	private double volumen;
	private double almacenado;
	private LinkedList<Generico> productos;

	public Camion(double volumen){
		this.volumen = volumen;
		almacenado = 0.0;
		productos = new LinkedList<Generico>();
	}

	public boolean guardar(Generico elemento){
		if(elemento.volumen() <= (volumen-almacenado)){
			productos.addLast(elemento);
			almacenado+=elemento.volumen();
			return true;		
		}
		return false;
	}
}
