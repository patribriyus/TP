public interface Generico extends Volumen{

}
