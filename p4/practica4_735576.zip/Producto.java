public class Producto extends General implements Generico{
	
	public Producto(double volumen, String info){
		super(volumen, info);
	}

}
