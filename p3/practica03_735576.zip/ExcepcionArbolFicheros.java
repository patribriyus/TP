public class ExcepcionArbolFicheros extends Exception {
	
	private String error;
	
	public ExcepcionArbolFicheros(String s) {
		error=s;
	}
	
	public String toString(){
		return error.toString();
	}
}