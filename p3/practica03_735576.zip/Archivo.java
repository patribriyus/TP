public class Archivo extends Nodos{

	public Archivo(String nom, int tam){
		super(nom,tam);
	}
	
	public char queSoy(){
		return 'a';
	}

}
