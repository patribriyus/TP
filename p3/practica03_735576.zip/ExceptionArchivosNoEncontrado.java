public class ExceptionArchivosNoEncontrado extends ExcepcionArbolFicheros {
	public ExceptionArchivosNoEncontrado (String s) {
		super(s);
	}
	
	public String toString(){
		return super.toString();
	}
}
