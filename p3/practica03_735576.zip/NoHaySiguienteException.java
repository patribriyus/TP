public class NoHaySiguienteException extends Exception {
	public NoHaySiguienteException(String s) {
		super(s);
	}
}