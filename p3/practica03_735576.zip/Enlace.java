import java.util.LinkedList;

public class Enlace extends Nodos{

	private Nodos nodo;
	private LinkedList<Directorio> pila;
	
	public Enlace(Nodos nodo, String nombre, LinkedList<Directorio> pila){
		super(nombre,nodo.tamanyo);
		this.nodo=nodo;
		this.pila=pila;
	}
	
	public char queGuardo(){
		return nodo.queSoy();
	}
	
	public LinkedList<Directorio> ruta(){
		return pila;
	}

	public char queSoy() {
		return 'l';
	}
	
	public int tamanyo(){
		return nodo.tamanyo;
	}
	
	public Nodos devuelve(){
		return nodo;
	}
}