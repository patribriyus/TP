public class ExceptionAccesoCarpeta extends ExcepcionArbolFicheros {
	public ExceptionAccesoCarpeta (String s) {
		super(s);
	}
	
	public String toString(){
		return super.toString();
	}
}