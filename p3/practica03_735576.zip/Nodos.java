public abstract class Nodos {

	private String nombre;
	public int tamanyo;
	
	public Nodos(String nom, int tamanyo){
		nombre=nom;
		this.tamanyo=tamanyo;
	}
	
	public void setNombre(String nom){
		nombre=nom;
	}
	
	public void setTamanyo(int tam){
		tamanyo=tam;
	}
	
	public String getNombre(){
		return nombre;
	}
	
	public int getTamanyo(){
		return tamanyo;
	}
	
	abstract char queSoy();

}
