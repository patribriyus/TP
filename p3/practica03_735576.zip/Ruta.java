import java.util.Iterator;
import java.util.LinkedList;


public class Ruta {

	private LinkedList<Directorio> pila;
	
	public Ruta(Directorio dir) throws ExcepcionArbolFicheros{
		pila = new LinkedList<Directorio>();
		if(dir==null){
			throw new ExcepcionArbolFicheros("Error al crear sistema de ficheros");
		}
		pila.addLast(dir);
	}
	
	public String pwd(){
		String ruta="";
		Iterator<Directorio> it=pila.iterator();
		while(it.hasNext()){
			ruta+=it.next().toString();
			ruta+="/";
		}
		return ruta;
	}
	
	public void ls(){
		pila.getLast().listar();
	}
	
	public void cd(String ruta) throws ExceptionAccesoCarpeta, ExceptionArchivosNoEncontrado{
		LinkedList<Directorio> pilaaux = new LinkedList<Directorio>(pila);
		if(ruta.charAt(0)=='/'){
			while(pila.size()!=1){
				pila.removeLast();
			}
			if(ruta.length()>1){
				ruta=(String) ruta.subSequence(1, ruta.length());
			}
		}
		String[] T = ruta.split("/");
		for(int i=0; i<T.length; i++){
			if(T[i].compareTo(".")==0){}
			else if(T[i].compareTo("..")==0){
				if(pila.size()!=1){
					pila.removeLast();
				}
				else{
					pila=pilaaux;
					throw new ExceptionAccesoCarpeta("Fallo al tratar de acceder a carpeta superior");
				}
			}
			else{
				try {
					Nodos aux=pila.getLast().buscar(T[i]);
					if(aux.queSoy()=='d'){
						pila.addLast((Directorio) aux);
					}
					else if(aux.queSoy()=='l'){
						Enlace enl=(Enlace) aux;
						pila=enl.ruta();
						pila.add((Directorio) enl.devuelve());
					}
				} catch (ExceptionArchivosNoEncontrado e) {
					pila=pilaaux;
					throw new ExceptionArchivosNoEncontrado("Nombre del fichero o carpeta no existe");
				}
			}
		}
	}
	
	public void mkdir(String nom) throws ExceptionSobreEscritura{
		Directorio dir=null;
		try {
			dir=pila.getLast().buscarDir(nom);
		} catch (ExceptionArchivosNoEncontrado e) {
			pila.getLast().anyadir(new Directorio(nom));
		}
		if(dir!=null){
			throw new ExceptionSobreEscritura("El archivo ya existe");
		}
	}
	
	public void stat(String element) throws ExceptionArchivosNoEncontrado, ExceptionAccesoCarpeta{
		LinkedList<Directorio> pilaaux = new LinkedList<Directorio>(pila);
		if(element.compareTo(".")==0){
			int tamanyo = pila.getLast().getTamanyo();
			System.out.println("El tamanyo es " + tamanyo + " bytes");
		}
		else{
			if(element.charAt(0)=='/'){
				if(element.length()>1){
					element=(String) element.subSequence(1, element.length());
				}
				String[] T = element.split("/");
				cd("/");
				for(int i=0; i<T.length-1; i++){
					cd(T[i]);
				}
				
				int tamanyo = pila.getLast().buscar(T[T.length-1]).getTamanyo();
				System.out.println("El tamanyo es " + tamanyo + " bytes");
				pila = pilaaux;
			}
			else{
				int tamanyo = pila.getLast().buscar(element).getTamanyo();
				System.out.println("El tamanyo es " + tamanyo + " bytes");
			}
		}
	}
	
	public void vim(String file, int size) throws ExceptionArchivosNoEncontrado{
			try {
				Nodos nodo=pila.getLast().buscar(file);
				if(nodo.tamanyo>size){
					int aux=nodo.tamanyo-size;
					nodo.tamanyo=size;
					pila.getLast().setTamanyo(pila.getLast().getTamanyo()-aux);
				}
				else{
					int aux=size-nodo.tamanyo;
					nodo.tamanyo=size;
					pila.getLast().setTamanyo(pila.getLast().getTamanyo()+aux);
				}
				System.out.println("El tamayo del archivo "+ file +" ha cambiado a "+ size);
			} catch (ExceptionArchivosNoEncontrado e) {
				pila.getLast().anyadir(new Archivo(file, size));
			}
	}

	public void ln(String orig, String dest) throws ExceptionArchivosNoEncontrado, ExceptionAccesoCarpeta{
		LinkedList<Directorio> rutavieja=new LinkedList<Directorio>(pila);
		try {
			boolean salir=false;
			int i=0;
			if(orig.charAt(orig.length()-1)=='/'){
				orig=orig.substring(0, orig.length()-1);
			}
			for(i=orig.length()-1; i>=0 && !salir;--i){
				if(orig.charAt(i)=='/'){
					salir=true;
				}
			}
			String resto=orig.substring(i+2, orig.length());
			orig=orig.substring(0, i+1);
			cd(orig);
			Enlace enl=new Enlace(pila.getLast().buscar(resto),dest,pila);
			rutavieja.getLast().anyadir(enl);
			pila=rutavieja;
		} catch (ExceptionArchivosNoEncontrado e) {
			pila=rutavieja;
			throw new ExceptionArchivosNoEncontrado("El archivo que intenta linkear no existe");
		} catch (ExceptionAccesoCarpeta e) {
			pila=rutavieja;
			throw new ExceptionAccesoCarpeta("Error al acceder a la carpeta");
		}
	}
	
	public void rm(String borrar) throws ExceptionArchivosNoEncontrado, ExceptionAccesoCarpeta{
		LinkedList<Directorio> rutavieja=new LinkedList<Directorio>(pila);
		try{
			if(borrar.charAt(0)=='/'){
				if(borrar.length()>1){
					borrar=(String) borrar.subSequence(1, borrar.length());
				}
				String[] T = borrar.split("/");
				cd("/");
				for(int j=0; j<T.length-1; j++){
					cd(T[j]);
				}
				Directorio direct=pila.getLast();
				direct.borrar(T[T.length-1]);
			}
			else{
				Directorio direct=pila.getLast();
				direct.borrar(borrar);
			}
			
		} catch (ExceptionArchivosNoEncontrado e) {
			pila=rutavieja;
			throw new ExceptionArchivosNoEncontrado("El archivo que intenta linkear no existe");
		} catch (ExceptionAccesoCarpeta e) {
			pila=rutavieja;
			throw new ExceptionAccesoCarpeta("Error al acceder a la carpeta");
		}
	}
}