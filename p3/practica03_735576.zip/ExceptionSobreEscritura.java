public class ExceptionSobreEscritura extends ExcepcionArbolFicheros {
	public ExceptionSobreEscritura (String s) {
		super(s);
	}
	
	public String toString(){
		return super.toString();
	}
}