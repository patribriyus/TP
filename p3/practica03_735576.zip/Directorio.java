import java.util.Vector;
import java.util.Iterator;


public class Directorio extends Nodos{

	private Vector<Nodos> archivos;
	
	public Directorio(String nom){
		super(nom,0);
		tamanyo=0;
		archivos = new Vector<Nodos>();
	}
	
	public void listar(){
		Iterator<Nodos> it=archivos.iterator();
		while(it.hasNext()){
			System.out.println(it.next().getNombre());
		}
	}
	
	public String toString(){
		return super.getNombre();
	}
	
	public char queSoy(){
		return 'd';
	}
	
	public Directorio buscarDir(String nom) throws ExceptionArchivosNoEncontrado{
		Iterator<Nodos> it=archivos.iterator();
		Directorio aux=null;
		while(it.hasNext()){
			Nodos aux2=it.next();
			if(aux2.getNombre().compareTo(nom)==0){
				if(aux2.queSoy()=='d'){
					aux=(Directorio) aux2;
				}
				else if(aux2.queSoy()=='l'){
					Enlace enl=(Enlace) aux2;
					if(enl.devuelve().queSoy()=='d'){
						aux=(Directorio) aux2;
					}
				}
			}
		}
		if(aux!=null && aux.queSoy()=='d'){
			return aux;
		}
		else{
			throw new ExceptionArchivosNoEncontrado("No existe el archivo");
		}
	}
	
	public Nodos buscar(String nom) throws ExceptionArchivosNoEncontrado{
		Iterator<Nodos> it=archivos.iterator();
		Nodos aux=null;
		while(it.hasNext()){
			Nodos aux2=it.next();
			if(aux2.getNombre().compareTo(nom)==0){
					aux= aux2;
			}
		}
		if(aux!=null){
			return aux;
		}
		else{
			throw new ExceptionArchivosNoEncontrado("No existe el archivo");
		}
	}
	
	public void anyadir(Nodos nodo){
		archivos.add(nodo);
		super.tamanyo+=nodo.getTamanyo();
	}
	
	public void borrar(String nom) throws ExceptionArchivosNoEncontrado{
		Boolean encontrado=false;
		int i=0;
		while(i<archivos.size()){
			Nodos aux=archivos.get(i);
			if(aux.getNombre().compareTo(nom)==0 || aux.getNombre().compareTo("./.")==0){
				if(aux.queSoy()=='a'){
					archivos.removeElementAt(i);
					encontrado=true;
				}
				else if(aux.queSoy()=='l'){
					archivos.removeElementAt(i);
					encontrado=true;
				}
				else{
					encontrado=true;
					Directorio dir=(Directorio) aux;
					dir.borrar("./.");
					archivos.removeElementAt(i);
				}
			}
			i++;
		}
		if(!encontrado && nom.compareTo("./.")!=0){
			throw new ExceptionArchivosNoEncontrado("No existe el archivo");
		}
	}

	
}
